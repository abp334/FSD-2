import React from "react";
import Second from "./lib/Second";
import Third from "./lib/Third";
import Fourth from "./lib/Fourth";
import Fifth from "./lib/Fifth";
import Sixth from "./lib/Sixth";
import Seventh from "./lib/Seventh";
import Eighth from "./lib/Eighth";
import Nineth from "./lib/Nineth";
import Tenth from "./lib/Tenth";
import Prop1 from "./lib/Prop1";
import Ex2 from "./lib/Ex2";
import Event1 from "./lib/Event1";
import Event2 from "./lib/Event2";
import Event3 from "./lib/Event3";
import Event4 from "./lib/Event4";
import Event5 from "./lib/Event5";
const Myapp = () => {
  return (
    <div>
      <img src="image1.png" alt=""></img>
      <p style={{ color: "red", fontSize: 30 }}>
        <b>Hello</b>
      </p>
      <Fifth />
      <Sixth />
      <Seventh />
      <Eighth />
      <Nineth />
      <Tenth />
      <Prop1 />
      <Ex2 />
      <Event1 />
      <Event2 />
      <Event3 />
      <Event4 />
      <Event5 />
    </div>
  );
};

export default Myapp;
